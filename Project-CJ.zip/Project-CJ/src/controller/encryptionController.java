package controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;

import javafx.event.ActionEvent;

import javafx.scene.control.Label;

import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.FileChooser.ExtensionFilter;
import net.codejava.crypto.CryptoException;
import net.codejava.crypto.CryptoUtils;

public class encryptionController {
	@FXML
	private ImageView LabelT;
	@FXML
	private Button importFiles;
	@FXML
	private Label Label1;
	@FXML
	private Label Label2;
	@FXML
	private Label lable3;
	@FXML
	private Button sendFiles;
	@FXML
	private Label status;
	@FXML
	private Button encrypt;
	@FXML
	private Button clearBtn;
	@FXML
	private Button returnBtn;
	@FXML
	private Button decrypt;
	@FXML
	private Button saveFile;
	@FXML
	private ListView displayFileName;
	@FXML
	private TextField recNum;
	@FXML
	private TextField mess;
	
	
	//This is the variable you need to retrieve after selectFile() is called
	//Use this in your encryption/decryption methods
	//IF necessary, 
	private File selectedFile = null;
	
	//Event Listener on Button[#chatBtn].onAction
	@FXML
	public void startChat(ActionEvent event) 	
	{
		System.out.println("Loaded");
		if(recNum.getText() != null && !recNum.getText().isEmpty() && mess.getText() != null && !mess.getText().isEmpty()) 
		{
			
		}
		
		
	}
	
	// Event Listener on Button[#importFiles].onAction
	@FXML
	public File selectFile(ActionEvent event) {
		FileChooser fc = new FileChooser();
		fc.getExtensionFilters().addAll(
				new ExtensionFilter("Text Files", "*.txt"),
				new ExtensionFilter("PDF Files", "*.pdf"),
				new ExtensionFilter("Word Documents", "*.docx")
				);
		selectedFile = fc.showOpenDialog(null);
		
		if(selectedFile != null) 
		{
			displayFileName.getItems().add(selectedFile.getName());
			importFiles.setVisible(false);
			status.setText("File Selected!");
		}
		else 
		{
			System.out.println("File is not valid");
			status.setText("File is not valid!");
		}
		return selectedFile;
	}
	
	public void clearList(ActionEvent event) 
	{
		displayFileName.getItems().clear();
		importFiles.setVisible(true);
		status.setText("File Cleared!");
	}
	
	/*
	 * Make sure to uncomment the methods before filling them up!
	 * 
	*/
	//Encryption and Decryption methods below
	//Fill up the methods with your algorithms
	public void encryptSelected(ActionEvent event) 
	{
		 String key = "Mary has one cat";
	        File inputFile = selectedFile;
	        File encryptedFile = new File("C:\\Project Saved Files\\"+ selectedFile.getName() + ".encrypted");
	         
	        try {
	            CryptoUtils.encrypt(key, inputFile, encryptedFile);
	            status.setText("Encrypted!");
	        } catch (CryptoException ex) {
	            System.out.println(ex.getMessage());
	            ex.printStackTrace();
	        }
	}
	
	public void decryptSelected(ActionEvent event) 
	{
		FileChooser fc = new FileChooser();
		fc.setTitle("Select File to Decrypt...");
		fc.getExtensionFilters().addAll(
				new ExtensionFilter("Encrypted Files", "*.encrypted")
				);
		selectedFile = fc.showOpenDialog(null);
		
		if(selectedFile != null) 
		{
			String key = "Mary has one cat";
	        File encryptedFile = selectedFile;
	        File decryptedFile = new File("C:\\Project Saved Files\\" + selectedFile.getName() +".decrypted");
		try 
			{  
            	CryptoUtils.decrypt(key, encryptedFile, decryptedFile);
            	status.setText("File Decrypted!");
			} 
		catch (CryptoException ex) 
			{
            	System.out.println(ex.getMessage());
            	ex.printStackTrace();
        	}
		}
		else 
		{
			status.setText("Decryption Cancelled!");
		}
	}
	
	
	//For File Transfer algorithm
	public void exportFile(ActionEvent event) 
	{
		System.out.println("Working");
	}
	
	//For File Saving
	//Pre-Requisites : Final encrypted file name (e.g. Encrypted File)
	//Put said name into new FileWriter then run, writing needs completion
	public void saveSelected(ActionEvent event) 
	{
		FileChooser fc = new FileChooser();
		fc.setTitle("Choose location to Save File...");
		fc.getExtensionFilters().addAll(
				new ExtensionFilter("Text Files", "*.txt"),
				new ExtensionFilter("PDF Files", "*.pdf"),
				new ExtensionFilter("Word Documents", "*.docx")
				);
		selectedFile = fc.showSaveDialog(null);
		if(selectedFile != null) 
		{
			File file = new File(selectedFile.getAbsolutePath());
			PrintWriter outFile = null;
			
			try 
			{
				outFile = new PrintWriter(file);
				status.setText("File Saved!");
			}
			
			catch(FileNotFoundException e) 
			{
				e.printStackTrace();
			}
			
			outFile.close();
		}	

	}
	
	
	
	public void returnToMain(ActionEvent event) throws IOException
	{
		Scene myScene;
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("/model/mainMenu.fxml"));
		myScene = (Scene)((Node)event.getSource()).getScene();
		Stage stage = (Stage)(myScene).getWindow();
		Parent nextView = loader.load();
		stage.setScene(new Scene(nextView));
		stage.setTitle("Encryption");
		stage.show();
	}
}
