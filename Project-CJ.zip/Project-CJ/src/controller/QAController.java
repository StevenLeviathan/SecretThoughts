package controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

import javafx.event.ActionEvent;

public class QAController {
	@FXML
	private Button backBtn;

	// Event Listener on Button[#backBtn].onAction
	@FXML
	public void backToMain(ActionEvent event) throws IOException
	{
		Scene myScene;
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(getClass().getResource("/model/mainMenu.fxml"));
		myScene = (Scene)((Node)event.getSource()).getScene();
		Stage stage = (Stage)(myScene).getWindow();
		Parent nextView = loader.load();
		stage.setScene(new Scene(nextView));
		stage.setTitle("Encryption");
		stage.show();
	}
}
